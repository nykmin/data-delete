from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request, 'home.html')

def local(request):
    return render(request, 'local.html')

def international(request):
    return render(request, 'international.html')

def resource(request):
    return render(request, 'resource.html')

def bench(request):
    return render(request, 'bench.html')
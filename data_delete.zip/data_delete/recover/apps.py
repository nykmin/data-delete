from django.apps import AppConfig


class RecoverConfig(AppConfig):
    name = 'recover'
